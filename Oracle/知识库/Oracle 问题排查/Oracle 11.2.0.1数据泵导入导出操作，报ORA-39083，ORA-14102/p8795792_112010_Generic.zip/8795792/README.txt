
=========================================================================
Interim Patch for Base Bug: 8795792
=========================================================================

Date: Fri Sep 25 09:17:03 2009
-------------------------------------------------------------------------
 Platform Patch for          : Generic
 Product Patched             : ORCL_PF
 Product Version #           : 11.2.0.1.0
 RAC Rolling Installable     : YES


Bugs Fixed by this patch:
-------------------------
  8795792: DBMS_METADATA.GET_DDL GENERATES WRONG KEYWORDS FOR COMPRESSED INDEXES

Patch Preinstall Steps
----------------------

1. For non-recommended patches, you must have the exact symptoms
   described in the service request (SR).

2. Confirm the version of Perl installed and configured for the ORACLE_HOME.

Oracle requires that all customers have at least Perl 5.00503 installed
and configured for patching activities inside the ORACLE_HOME.  Follow
these steps to check the Perl version for the ORACLE_HOME being patched:

  - source the ORACLE_HOME environment
  - execute "perl -v"
  - verify that the returned version of Perl is 5.00503 or higher

If the Perl configured for the ORACLE_HOME is not at 5.00503 or
higher, follow the directions in this metalink note to update to
a more recent version:

 https://metalink.oracle.com/metalink/plsql/ml2_documents.showNOT?p_id=189489.1

3.  Verify the OUI Inventory.

OPatch needs access to a valid OUI inventory to apply patches.
Validate the OUI inventory with the following command:

  opatch lsinventory

If the command errors out, contact Oracle Support and work to validate
and verify the inventory setup before proceeding.

4.  Review and download the latest version of OPatch.

Oracle recommends that all customers be on the latest version of OPatch.
Please review the following metalink note and follow the instructions
to update to the latest version if needed:

 https://metalink.oracle.com/metalink/plsql/ml2_documents.showNOT?p_id=224346.1

5.  Confirm executables appear in your system PATH.

The patching process will use the unzip and the opatch executables.  After
sourcing the ORACLE_HOME environment, confirm both of these exist before
continuing:

  - "which opatch"
  - "which unzip"

If either of these executables do not show in the PATH, correct the problem
before proceeding.

6.  Create a location for storing the unzipped patch.  This location
will be referred to later in the document as <PATCH_TOP>.

7.  Unzip the patch zip file into the <PATCH_TOP>.

  unzip -d <PATCH_TOP> p8795792_112010_Generic.zip

8.  Shut down services running from the ORACLE_HOME.

Before applying this patch, do a clean shut down of all services
running from the ORACLE_HOME.

  (a) In a non-RAC environment:

  Shut down all services that are running from this ORACLE_HOME.
  Confirm the return status from each shutdown command to verify
  the shutdown is successful and there are no errors.

  (b) In a RAC environment:

  For each node in the RAC system, shut down the services for
  the specific machine that are running from the ORACLE_HOME.
  OPatch will be used on each node in the RAC system one at
  a time.  If this patch is not rolling RAC installable treat
  it as a non-RAC environment and shut down all services.

  As an example, in the case of a two node RAC system:
     1. Stop instances running on node 1.
     2. Run 'opatch apply <PATCH_TOP>/8795792' on node 1.
     3. When the apply finishes, opatch asks for confirmation 
        before going on to apply the patch to node 2.
     4. Start instances on node 1.
     5. Stop instances running on node 2.
     6. Ask opatch to continue to applying the patch to node 2.
     7. Start instances on node 2.      


Patch Installation Steps:
-------------------------

1.  Set your current directory to the directory where the patch is located.

  cd <PATCH_TOP>/8795792

2.  Apply the patch.

Use the following command to apply the patch to the ORACLE_HOME:

  opatch apply

When OPatch starts, it will validate the patch and make sure there
are no conflicts with the software already installed in the ORACLE_HOME.
OPatch categorizes two types of conflicts:

  (a) Conflicts with a patch already applied to the ORACLE_HOME
  In this case, please stop the patch installation and contact
  Oracle Support Services.

  (b) Conflicts with subset patch already applied to the ORACLE_HOME
  In this case, please continue the install, as the new patch
  contains all the fixes from the existing patch in the ORACLE_HOME.
  The subset patch will automatically be rolled back prior to the
  installation of the new patch.

Patch Post Install Instructions:
--------------------------------

sqlplus "/ as sysdba"
exec SYS.DBMS_METADATA_UTIL.LOAD_STYLESHEETS;


Patch Deinstallation Instructions:
----------------------------------

1. Make sure to follow the same pre-install steps when deinstalling
a patch.  This includes verifying the inventory and shutting down
any services running from the ORACLE_HOME / machine before rolling
the patch back.

2. Change to the directory where the patch was unzipped.
  cd <PATCH_TOP>/8795792

3. Run OPatch to deinstall the patch.
  opatch rollback -id 8795792

